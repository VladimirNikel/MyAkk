var searchData=
[
  ['resource',['Resource',['../classpsswdmng_1_1models_1_1_resource.html',1,'psswdmng::models']]]
];
