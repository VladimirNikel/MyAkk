var indexSectionsWithContent =
{
  0: "acgip",
  1: "p",
  2: "acgi"
};

var indexSectionNames =
{
  0: "all",
  1: "namespaces",
  2: "functions"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Пространства имен",
  2: "Функции"
};

